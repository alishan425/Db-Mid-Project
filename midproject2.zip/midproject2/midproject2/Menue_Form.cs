﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midproject2
{
    public partial class Menue_Form : Form
    {
        public Menue_Form()
        {
            InitializeComponent();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form LookUp = new LookUp();
            LookUp.ShowDialog();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form Student = new Student();
            Student.ShowDialog();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form Clo = new Clo();
            Clo.ShowDialog();
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form Rubric = new Rubric();
            Rubric.ShowDialog();
            
        }

        private void Menue_Form_Load(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form RubricLevel = new RubricLevel();
            RubricLevel.ShowDialog();
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form Assessment = new Assessment();
            Assessment.ShowDialog();
            
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form StartForm = new StartForm();
            StartForm.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form StudentAttendence = new StudentAttendence();
            StudentAttendence.ShowDialog();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form StudentResult = new StudentResult();
            StudentResult.ShowDialog();
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form ClassAttendence = new ClassAttendence();
            ClassAttendence.ShowDialog();
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form AssessmentComponent = new AssessmentComponent();
            AssessmentComponent.ShowDialog();
            
        }
    }
}
