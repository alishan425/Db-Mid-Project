﻿using CRUD_Operations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace midproject2
{
    public partial class RubricLevel : Form
    {
        public RubricLevel()
        {
            InitializeComponent();
        }

        private void RubricLevel_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("INSERT INTO RubricLevel (RubricId,Details, MeasurementLevel) VALUES (@RubricId, @Details, @MeasurementLevel)", con);

            cmd.Parameters.AddWithValue("@RubricId", textBox2.Text);
            cmd.Parameters.AddWithValue("@Details", textBox4.Text);
            cmd.Parameters.AddWithValue("@MeasurementLevel", textBox3.Text);

            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully saved");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form Menue_Form = new Menue_Form();
            Menue_Form.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from RubricLevel", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT * FROM RubricLevel WHERE Details = @Details", con);
            cmd.Parameters.AddWithValue("@Details", textBox4.Text);

            string Title = textBox4.Text;
            cmd.ExecuteNonQuery();
            this.Hide();
            Form Update_Rubric_Level_Form = new Update_Rubric_Level_Form(Title);
            Update_Rubric_Level_Form.ShowDialog();
        }
    }
}
