﻿using CRUD_Operations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midproject2
{
    public partial class Update_Student_info_form : Form
    {
        private string old_first_name;
        private string old_last_name;
        private string old_registration_no;
        public Update_Student_info_form(string old_first_name, string old_last_name, string old_registration_no)
        {
            this.old_first_name = old_first_name;
            this.old_last_name = old_last_name;
            this.old_registration_no = old_registration_no;
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("UPDATE Student SET FirstName = @new_First_Name, LastName = @new_Last_Name, Contact = @new_Contact , Email = @new_Email, RegistrationNumber = @new_RegistrationNumber, Status = @new_Status where FirstName = @old_first_name and LastName = @old_last_name and RegistrationNumber = @old_registration_no ", con);
            cmd.Parameters.AddWithValue("@new_First_Name", textBox5.Text);
            cmd.Parameters.AddWithValue("@new_Last_Name", textBox6.Text);
            cmd.Parameters.AddWithValue("@new_Contact", textBox2.Text);
            cmd.Parameters.AddWithValue("@new_Email", textBox3.Text);
            cmd.Parameters.AddWithValue("@new_RegistrationNumber", textBox4.Text);
            cmd.Parameters.AddWithValue("@new_Status", textBox7.Text);
            cmd.Parameters.AddWithValue("@old_first_name", old_first_name);
            cmd.Parameters.AddWithValue("@old_last_name", old_last_name);
            cmd.Parameters.AddWithValue("@old_registration_no", old_registration_no);

            int rowsAffected = cmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Successfully Updated");
            }
            else
            {
                MessageBox.Show("Not Found");
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void Update_Student_info_form_Load(object sender, EventArgs e)
        {
           

            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Student WHERE FirstName = @FirstName AND LastName = @LastName AND RegistrationNumber = @RegistrationNumber", con);
            cmd.Parameters.AddWithValue("@FirstName", old_first_name);
            cmd.Parameters.AddWithValue("@LastName", old_last_name);
            cmd.Parameters.AddWithValue("@RegistrationNumber", old_registration_no);

            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                if (reader.Read())
                {
                    // Populate text boxes with fetched data
                    textBox5.Text = reader["FirstName"].ToString();
                    textBox6.Text = reader["LastName"].ToString();
                    textBox2.Text = reader["Contact"].ToString();
                    textBox3.Text = reader["Email"].ToString();
                    textBox4.Text = reader["RegistrationNumber"].ToString();
                    textBox7.Text = reader["Status"].ToString();
                }
            }

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form Student = new Student();
            Student.ShowDialog();
        }
    }
}
