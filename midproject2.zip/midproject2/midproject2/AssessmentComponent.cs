﻿using CRUD_Operations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midproject2
{
    public partial class AssessmentComponent : Form
    {
        public AssessmentComponent()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form Menue_Form = new Menue_Form();
            Menue_Form.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {

            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from AssessmentComponent", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("INSERT INTO AssessmentComponent (Name,RubricId,TotalMarks, DateCreated, DateUpdated,AssessmentId) VALUES (@Name, @RubricId, @TotalMarks, @DateCreated,@DateUpdated,@AssessmentId)", con);

            cmd.Parameters.AddWithValue("@Name", textBox2.Text);
            cmd.Parameters.AddWithValue("@RubricId", textBox6.Text);
            cmd.Parameters.AddWithValue("@TotalMarks", textBox5.Text);
            cmd.Parameters.AddWithValue("@DateCreated", textBox4.Text);
            cmd.Parameters.AddWithValue("@DateUpdated", textBox3.Text);
            cmd.Parameters.AddWithValue("@AssessmentId", textBox7.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully saved");
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT * FROM AssessmentComponent WHERE Name = @Name", con);
            cmd.Parameters.AddWithValue("@Name", textBox2.Text);

            string Title = textBox2.Text;
            cmd.ExecuteNonQuery();
            this.Hide();
            Form update_Assessment_component_form = new update_Assessment_component_form(Title);
            update_Assessment_component_form.ShowDialog();
        }

        private void AssessmentComponent_Load(object sender, EventArgs e)
        {

        }
    }
}
