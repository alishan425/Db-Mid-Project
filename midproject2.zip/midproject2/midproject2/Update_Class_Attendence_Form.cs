﻿using CRUD_Operations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace midproject2
{
    public partial class Update_Class_Attendence_Form : Form
    {
        private string old_date;

        public Update_Class_Attendence_Form(string old_date)
        {
            this.old_date = old_date;
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form ClassAttendence = new ClassAttendence();
            ClassAttendence.ShowDialog();
        }

        private void Update_Class_Attendence_Form_Load(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT * FROM ClassAttendance WHERE AttendanceDate = @old_date", con);
            cmd.Parameters.AddWithValue("@old_date", old_date); // Corrected parameter name

            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                if (reader.Read())
                {
                    // Populate text boxes with fetched data
                    textBox2.Text = reader["AttendanceDate"].ToString();
                    
                }
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("UPDATE ClassAttendence SET AttendanceDate = @new_AttendanceDate where AttendanceDate = @old_date", con);
            cmd.Parameters.AddWithValue("@new_AttendanceDate", textBox2.Text);
            cmd.Parameters.AddWithValue("@old_date", old_date);
            int rowsAffected = cmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Successfully Updated");
            }
            else
            {
                MessageBox.Show("Not Found");
            }
        }
    }
}
