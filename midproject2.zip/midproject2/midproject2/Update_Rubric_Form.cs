﻿using CRUD_Operations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace midproject2
{
    public partial class Update_Rubric_Form : Form
    {
        private string old_details;

        public Update_Rubric_Form(string old_details)
        {
            this.old_details = old_details;
            InitializeComponent();
        }

        private void Update_Rubric_Form_Load(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Rubric WHERE Details = @old_details", con);
            cmd.Parameters.AddWithValue("@old_details", old_details); // Corrected parameter name

            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                if (reader.Read())
                {
                    // Populate text boxes with fetched data
                    textBox3.Text = reader["Details"].ToString();
                    textBox2.Text = reader["CloId"].ToString();
                    
                }
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("UPDATE Rubric SET Details = @new_Details, CloId = @new_CloId where Details = @old_details", con);
            cmd.Parameters.AddWithValue("@new_Details", textBox3.Text);
            cmd.Parameters.AddWithValue("@new_CloId", textBox2.Text);
            
            cmd.Parameters.AddWithValue("@old_details", old_details);

            int rowsAffected = cmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Successfully Updated");
            }
            else
            {
                MessageBox.Show("Not Found");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form Rubric = new Rubric();
            Rubric.ShowDialog();
        }
    }
}
