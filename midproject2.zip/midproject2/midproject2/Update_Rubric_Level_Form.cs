﻿using CRUD_Operations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace midproject2
{
    public partial class Update_Rubric_Level_Form : Form
    {
        private string old_details;

        public Update_Rubric_Level_Form(string old_details)
        {
            this.old_details = old_details;
            InitializeComponent();
        }

        private void Update_Rubric_Level_Form_Load(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT * FROM RubricLevel WHERE Details = @old_details", con);
            cmd.Parameters.AddWithValue("@old_details", old_details); // Corrected parameter name

            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                if (reader.Read())
                {
                    // Populate text boxes with fetched data
                    textBox2.Text = reader["RubricId"].ToString();
                    textBox4.Text = reader["Details"].ToString();
                    textBox3.Text = reader["MeasurementLevel"].ToString();
                  
                }
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("UPDATE RubricLevel SET RubricId = @new_RubricId, Details = @new_Details, MeasurementLevel = @new_MeasurementLevel  where Details = @old_details", con);
            cmd.Parameters.AddWithValue("@new_RubricId", textBox2.Text);
            cmd.Parameters.AddWithValue("@new_Details", textBox4.Text);
            cmd.Parameters.AddWithValue("@new_MeasurementLevel", textBox3.Text);

            cmd.Parameters.AddWithValue("@old_details", old_details);
            int rowsAffected = cmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Successfully Updated");
            }
            else
            {
                MessageBox.Show("Not Found");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form RubricLevel = new RubricLevel();
            RubricLevel.ShowDialog();

        }
    }
}
