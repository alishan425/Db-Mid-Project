﻿using CRUD_Operations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace midproject2
{
    public partial class Update_Student_Attendence : Form
    {
        private string old_StudentId;

        public Update_Student_Attendence(string old_StudentId)
        {
            this.old_StudentId = old_StudentId;
            InitializeComponent();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form StudentAttendence = new StudentAttendence();
            StudentAttendence.ShowDialog();
        }

        private void Update_Student_Attendence_Load(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT * FROM StudentAttendance WHERE StudentId = @old_StudentId", con);
            cmd.Parameters.AddWithValue("@old_StudentId", old_StudentId); // Corrected parameter name

            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                if (reader.Read())
                {
                    // Populate text boxes with fetched data
                    textBox3.Text = reader["AttendanceStatus"].ToString();
                  
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("UPDATE StudentAttendance SET AttendanceStatus = @new_AttendanceStatus where StudentId = @old_StudentId", con);
            cmd.Parameters.AddWithValue("@new_AttendanceStatus", textBox3.Text);
            cmd.Parameters.AddWithValue("@old_StudentId", old_StudentId);

            int rowsAffected = cmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Successfully Updated");
            }
            else
            {
                MessageBox.Show("Not Found");
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
