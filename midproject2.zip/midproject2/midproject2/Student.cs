﻿using CRUD_Operations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midproject2
{
    public partial class Student : Form
    {
        public Student()
        {
            InitializeComponent();
        }

        private void Student_Load(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form Menue_Form = new Menue_Form();
            Menue_Form.ShowDialog();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
             SqlCommand cmd = new SqlCommand("INSERT INTO Student (FirstName, LastName, Contact, Email, RegistrationNumber, Status) VALUES ( @FirstName, @LastName, @Contact, @Email, @RegistrationNumber, @Status)", con);

             cmd.Parameters.AddWithValue("@Id", textBox1.Text);
             cmd.Parameters.AddWithValue("@FirstName", textBox5.Text);
             cmd.Parameters.AddWithValue("@LastName", textBox6.Text);
             cmd.Parameters.AddWithValue("@Contact", textBox2.Text);
             cmd.Parameters.AddWithValue("@Email", textBox3.Text);
             cmd.Parameters.AddWithValue("@RegistrationNumber", textBox4.Text);
             cmd.Parameters.AddWithValue("@Status", textBox7.Text);   
             cmd.ExecuteNonQuery();
             MessageBox.Show("Successfully saved");
        }

        





        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("DELETE FROM Student WHERE FirstName = @FirstName AND LastName = @LastName AND RegistrationNumber = @RegistrationNumber", con);

            cmd.Parameters.AddWithValue("@FirstName", textBox5.Text);
            cmd.Parameters.AddWithValue("@LastName", textBox6.Text);
            cmd.Parameters.AddWithValue("@RegistrationNumber", textBox4.Text);

            
            int rowsAffected = cmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Successfully deleted");
            }
            else
            {
                MessageBox.Show("Not Found");
            }

            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Student WHERE FirstName = @FirstName AND LastName = @LastName AND RegistrationNumber = @RegistrationNumber", con);
            cmd.Parameters.AddWithValue("@FirstName", textBox5.Text);
            cmd.Parameters.AddWithValue("@LastName", textBox6.Text);
            cmd.Parameters.AddWithValue("@RegistrationNumber", textBox4.Text);
            string FirstName = textBox5.Text;
            string LastName = textBox6.Text;
            string RegistrationNumber = textBox4.Text;
            cmd.ExecuteNonQuery();
            this.Hide();
            Form Update_Student_info_form = new Update_Student_info_form(FirstName, LastName, RegistrationNumber);
            Update_Student_info_form.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Student", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
    }
}
