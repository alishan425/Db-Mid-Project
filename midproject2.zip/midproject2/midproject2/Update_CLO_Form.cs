﻿using CRUD_Operations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace midproject2
{
    public partial class Update_CLO_Form : Form
    {
        private string old_name;

        public Update_CLO_Form(string old_name)
        {
            this.old_name = old_name;
            InitializeComponent();
        }

        private void Update_CLO_Form_Load(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Clo WHERE Name = @old_name", con);
            cmd.Parameters.AddWithValue("@old_name", old_name); // Corrected parameter name

            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                if (reader.Read())
                {
                    // Populate text boxes with fetched data
                    textBox3.Text = reader["Name"].ToString();
                    textBox2.Text = reader["DateCreated"].ToString();
                    textBox4.Text = reader["DateUpdated"].ToString();
             
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("UPDATE Clo SET Name = @new_Name, DateCreated = @new_DateCreated, DateUpdated = @new_DateUpdated where Name = @old_name", con);
            cmd.Parameters.AddWithValue("@new_Name", textBox3.Text);
            cmd.Parameters.AddWithValue("@new_DateCreated", textBox2.Text);
            cmd.Parameters.AddWithValue("@new_DateUpdated", textBox4.Text);
            cmd.Parameters.AddWithValue("@old_name", old_name);
            int rowsAffected = cmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Successfully Updated");
            }
            else
            {
                MessageBox.Show("Not Found");
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form Clo = new Clo();
            Clo.ShowDialog();
        }
    }
}
