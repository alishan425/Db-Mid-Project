﻿using CRUD_Operations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace midproject2
{
    public partial class Update_Assessment_Form : Form
    {
        private string old_Title;
        
        public Update_Assessment_Form(string old_Title)
        {
            this.old_Title = old_Title;
            InitializeComponent();
        }
       

        private void button4_Click(object sender, EventArgs e)
        {

            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("UPDATE Assessment SET Title = @new_Title, DateCreated = @new_DateCreated, TotalMarks = @new_TotalMarks , TotalWeightage = @new_TotalWeightage  where Title = @old_Title", con);
            cmd.Parameters.AddWithValue("@new_Title", textBox2.Text);
            cmd.Parameters.AddWithValue("@new_DateCreated", textBox3.Text);
            cmd.Parameters.AddWithValue("@new_TotalMarks", textBox4.Text);
            cmd.Parameters.AddWithValue("@new_TotalWeightage", textBox5.Text);
            cmd.Parameters.AddWithValue("@old_Title", old_Title);

            int rowsAffected = cmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Successfully Updated");
            }
            else
            {
                MessageBox.Show("Not Found");
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Update_Assessment_Form_Load(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Assessment WHERE Title = @old_Title", con);
            cmd.Parameters.AddWithValue("@old_Title", old_Title); // Corrected parameter name

            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                if (reader.Read())
                {
                    // Populate text boxes with fetched data
                    textBox2.Text = reader["Title"].ToString();
                    textBox3.Text = reader["DateCreated"].ToString();
                    textBox4.Text = reader["TotalMarks"].ToString();
                    textBox5.Text = reader["TotalWeightage"].ToString();
                }
            }
        }


        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form Assessment = new Assessment();
            Assessment.ShowDialog();
        }
    }
}
